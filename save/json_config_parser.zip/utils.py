import torch
import gym
import random
import numpy as np
import datetime

from collections import deque
from json_config_parser import Json_Config_Parser
from Off_Policy_Agent import Agent

from PIL import Image

def get_optimizer(parms, agent):

    if parms['name'] =='adam':
        optimizer =torch.optim.Adam(agent.parameters(), lr=parms['learning_rate'], weight_decay=parms['weight_decay'], eps=parms['eps'])
    elif parms['name'] =='sgd':
        optimizer =torch.optim.SGD(agent.parameters(), lr=parms['learning_rate'], weight_decay=parms['weight_decay'],
                        momentum=parms['momentum'])
    else:
        optimizer = None

    return optimizer



class OFF_Policy:

    def __init__(self,file_name):
        self.parser = Json_Config_Parser(file_name)
        self.parm = self.parser.load_parser()
        self.agent_parms = self.parser.load_agent_parser()
        self.optimizer_parms = self.parser.load_optimizer_parser()

        self.agent = Agent(self.agent_parms).load_agent()
        self.target_agent = Agent(self.agent_parms).load_agent()

        if self.parm['load_path'] !="None":
            self.agent.load_state_dict(torch.load(self.parm['load_path']))
        self.target_agent.load_state_dict(self.agent.state_dict())


        self.env = gym.make(self.parm['env_name'])

        self.decay = self.parm['decay_epsilon']
        self.obs_set = deque(maxlen=self.parm['state_size'][0])
        self.replay_memory = deque(maxlen=self.parm['size_replay_memory'])
        self.optimizer = get_optimizer(self.optimizer_parms, self.agent)
        self.discount_factor = self.parm['discount_factor']
        self.optimizer.zero_grad()

        self.state_size = self.parm['state_size']
        self.action_size = self.parm['action_size']

        self.gpu =torch.device(self.parm['gpu_name'])
        self.cpu = torch.device('cpu')

        self.Exploration_method = self.parm['Exploration_method']
        self.epsilon_min = self.parm['epsilon_min']
        self.batch_size = self.parm['batch_size']

        self.run_episode = self.parm['run_episode']
        self.start_episode = self.parm['start_episode']
        self.update_step = self.parm['update_step']
        self.show_episode = self.parm['show_episode']

        self.save_path = self.parm['save_path']
        date_time = datetime.datetime.now().strftime("%Y%m%d-%H-%M-%S")

        self.save_path = self.save_path +self.parm['env_name']+'_'+date_time +'.pth'

        self.inference_mode = self.parm['inference_mode'] =='True'





        if len(self.state_size) >= 3:
            self.mode = 'Image'
        else:
            self.mode = 'Vector'

        if  self.Exploration_method== 'e_greedy':
            self.epsilon = self.parm['epsilon']

        if self.inference_mode:
            self.epsilon =0
            self.epsilon_min = 0


    def reset(self):

        for i in range(self.state_size[0]):
            self.obs_set.append(np.zeros([i for i in self.state_size[1:]]))


    def preprocess_state(self, obs):

        state = np.zeros(self.state_size)
        if self.mode =='Image':
            obs = Image.fromarray(obs)
            obs = np.array(obs.resize(self.state_size[1:]).convert('1'))
        self.obs_set.append(obs)

        for i in range(self.state_size[0]):
            state[i] = self.obs_set[i]

        if self.mode == 'Image':
            state = np.uint8(state)

        return state

    def append_memory(self, sarsd):
        self.replay_memory.append(sarsd)


    def get_action(self, state):

        if ~torch.is_tensor(state):
            state = torch.tensor(state).to(self.gpu)


        size = [-1]
        for i in self.state_size:
            size.append(i)
        state = state.view(size)

        if self.Exploration_method =='e_greedy':
            if self.epsilon > np.random.rand():
                return np.random.randint(0,self.action_size)
            else:
                Q = self.agent.forward(state).to(self.gpu)
                a = torch.argmax(Q).detach().to(self.cpu)
                return a.numpy()

        elif self.Exploration_method =='boltzman':
            Q = self.agent.forward(state).to(self.gpu)
            Q = Q.detach().to(self.cpu)
            Q = torch.softmax(Q, dim=-1).squeeze().numpy()
            action = [i for i in range(self.action_size)]
            a = np.random.choice(action, p=Q)

            return a

    def target_network_update(self):
        self.target_agent.load_state_dict(self.agent.state_dict())

    def train(self, done):

        if done:
            if self.epsilon > self.epsilon_min:
                self.epsilon *= self.decay

        mini_batch = random.sample(self.replay_memory, self.batch_size)

        states = []
        actions = []
        rewards = []
        next_states = []
        dones = []

        for i in range(self.batch_size):
            states.append(mini_batch[i][0])
            actions.append([mini_batch[i][1]])
            rewards.append(mini_batch[i][2])
            next_states.append(mini_batch[i][3])
            dones.append(mini_batch[i][4])


        target = [torch.max(self.target_agent.forward(next_state).detach()) for next_state in next_states]
        actions_ = []

        for i in range(self.batch_size):

            if dones[i]:
                target[i] =torch.tensor(rewards[i]).to(self.gpu).detach()
            else:
                target[i] = rewards[i] + self.discount_factor * target[i]
            a = np.array(actions[i])
            a = a.reshape(1)
            actions_.append([i,a[0]])

        loss = self.agent.loss(states, target, actions_)

        loss.backward()
        self.optimizer.step()
        self.optimizer.zero_grad()


        return loss

    def run(self):

        losses = []
        rewards = []
        step = 0
        for episode in range(self.run_episode):

            episode_loss = []
            episode_reward = 0

            ob = self.env.reset()
            self.reset()
            state = self.preprocess_state(ob)
            done = False

            while done==False:
                step += 1
                a = self.get_action(state)
                obs, reward,done,_ = self.env.step(a)
                next_state = self.preprocess_state(obs)
                self.append_memory((state, a, reward, next_state, done))
                if episode >= self.start_episode and self.inference_mode == False :
                    loss = self.train(done)
                    episode_loss.append(loss.to(self.cpu).detach().numpy())
                state = next_state
                episode_reward+= reward
                if self.parm['render_mode']=='True':
                    self.env.render()
                if episode > self.start_episode and (step + 1) % self.update_step == 0 and self.inference_mode == False:
                    self.target_network_update()
                if done:

                    episode_loss = np.array(episode_loss).mean()

                    losses.append(episode_loss)
                    rewards.append(episode_reward)

                    if (episode+1)%self.show_episode == 0 or self.inference_mode:
                        losses = np.array(losses).mean()
                        rewards = np.array(rewards).mean()
                        print('Episode : {:4d} // Step : {:5d} // Loss: {:3f} // Reward : {:3f} // Epsilon : {:3f}'.format(episode+1, step, losses, rewards, self.epsilon))
                        losses = []
                        rewards = []

                    if episode > self.start_episode and (episode + 1) % 100 == 0 and self.inference_mode==False:
                        torch.save(self.agent.state_dict(), self.save_path)

