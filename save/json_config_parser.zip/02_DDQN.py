import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import datetime

from collections import deque
import random
import gym

from PIL import Image

state_size = [4, 64, 64]
action_size = 3
replay_size = 50000

run_episode = 5000
start_train_episode = 50
batch_size = 32
discount_factor = 0.99

learning_rate = 1e-3
momentum = .9
weight_decay = 5e-4

update_step = 5000
show_episode = 5
save_episode = 100

game_name = 'Breakout-v0'
date_time = datetime.datetime.now().strftime("%Y%m%d-%H-%M-%S")

load_path = './save/' + game_name + '/'
save_path = './save/02_DDQN/' + game_name + '_' + date_time + '.pth'
load_mode = False

is_gpu = True
gpu = torch.device('cuda:0')
cpu = torch.device('cpu')

Exploration_method = 'e_greedy'  # 'boltzman', 'e_greedy'

epsilon_min = .1


class DDQN_Agent(nn.Module):

    def __init__(self):
        super(DDQN_Agent, self).__init__()
        # x_e = (x_i + 2 * padding - filter_size)/strides +1
        self.conv1 = nn.Conv2d(state_size[0], 32, 3, padding=1)
        self.conv2 = nn.Conv2d(32, 32, 3, padding=1)

        self.fc1 = nn.Linear(int((state_size[-1] / 4)) ** 2 * 32, 256)
        self.v = nn.Linear(256, 1)
        self.adv = nn.Linear(256, action_size)

        if is_gpu:
            self.conv1.to(gpu)
            self.conv2.to(gpu)
            self.fc1.to(gpu)
            self.v.to(gpu)
            self.adv.to(gpu)
        else:
            self.conv1.to(cpu)
            self.conv2.to(cpu)
            self.fc1.to(cpu)
            self.v.to(cpu)
            self.adv.to(cpu)

    def forward(self, state):

        if ~torch.is_tensor(state):
            state = torch.tensor(state)
        state = state.view((-1, state_size[0], state_size[1], state_size[2])).to(gpu)

        state = state.float()
        state = state / 255.

        x = F.max_pool2d(F.relu(self.conv1(state)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv2(x)), (2, 2))
        _, w, h, c = x.size()
        x = x.view((-1, w * h * c))
        x = F.relu(self.fc1(x))
        v = self.v(x)
        adv = self.adv(x)

        q = adv + v

        return q

    def loss(self, states, targets, actions):
        values = self.forward(states).to(gpu)
        values = torch.stack([values[action[0], action[1]] for action in actions])
        targets = torch.stack(targets).to(gpu)

        loss = torch.sum((values - targets).pow(2))

        return loss


class DDQN:

    def __init__(self):
        self.agent = DDQN_Agent()
        if load_mode:
            self.agent.load_state_dict(torch.load(load_path))

        self.target_agent = DDQN_Agent()
        self.target_agent.load_state_dict(self.agent.state_dict())
        self.env = gym.make('Breakout-v0')

        self.obs_set = deque(maxlen=state_size[0])
        self.replay_memory = deque(maxlen=replay_size)
        self.optimizer = torch.optim.SGD(self.agent.parameters(), lr=1e-3, momentum=momentum, weight_decay=weight_decay)
        self.optimizer.zero_grad()

        if Exploration_method == 'e_greedy':
            self.epsilon = 1.0

    def reset(self):

        for i in range(state_size[0]):
            self.obs_set.append(np.zeros((state_size[-1], state_size[-1])))

    def preprocess_state(self, obs):

        state = np.zeros(state_size)
        obs = Image.fromarray(obs)
        resized_obs = np.array(obs.resize(state_size[1:]).convert('1'))
        self.obs_set.append(resized_obs)

        for i in range(state_size[0]):
            state[i, :, :] = self.obs_set[i]

        return np.uint8(state)

    def append_memory(self, sarsd):
        self.replay_memory.append(sarsd)

    def get_action(self, state):

        if ~torch.is_tensor(state):
            state = torch.tensor(state).to(gpu)

        if state.ndim != 4:
            state = state.view((-1, state_size[0], state_size[1], state_size[2]))

        if Exploration_method == 'e_greedy':
            if self.epsilon > np.random.rand():
                return np.random.randint(0, action_size)
            else:
                Q = self.agent.forward(state).to(gpu)
                a = torch.argmax(Q).detach().to(cpu)
                return a.numpy()

        elif Exploration_method == 'boltzman':
            Q = self.agent.forward(state).to(gpu)
            Q = Q.detach().to(cpu)
            Q = torch.softmax(Q, dim=-1).squeeze().numpy()
            action = [i for i in range(action_size)]
            a = np.random.choice(action, p=Q)

            return a

    def target_network_update(self):
        self.target_agent.load_state_dict(self.agent.state_dict())

    def train(self, done):

        if done:
            if self.epsilon > epsilon_min:
                self.epsilon -= 1 / (run_episode - start_train_episode)

        mini_batch = random.sample(self.replay_memory, batch_size)

        states = []
        actions = []
        rewards = []
        next_states = []
        dones = []

        for i in range(batch_size):
            states.append(mini_batch[i][0])
            actions.append([mini_batch[i][1]])
            rewards.append(mini_batch[i][2])
            next_states.append(mini_batch[i][3])
            dones.append(mini_batch[i][4])

        target = [torch.max(self.target_agent.forward(next_state).detach()) for next_state in next_states]
        actions_ = []

        for i in range(batch_size):

            if dones[i]:
                target[i] = torch.tensor(rewards[i]).to(gpu)
            else:
                target[i] = rewards[i] + discount_factor * target[i]
            a = np.array(actions[i])
            a = a.reshape(1)
            actions_.append([i, a[0]])

        loss = self.agent.loss(states, target, actions_)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return loss

    def run(self):

        losses = []
        rewards = []
        step = 0
        for episode in range(run_episode):

            episode_loss = []
            episode_reward = 0

            ob = self.env.reset()
            self.reset()
            state = self.preprocess_state(ob)
            done = False

            while done == False:

                if episode < start_train_episode:
                    a = np.random.choice([0, 1, 2], size=1)
                    obs, reward, done, _ = self.env.step(a + 1)
                    #                     self.env.render()
                    next_state = self.preprocess_state(obs)
                    self.append_memory((state, a, reward, next_state, done))
                    state = next_state


                else:
                    step += 1
                    a = self.get_action(state)
                    obs, reward, done, _ = self.env.step(a + 1)
                    next_state = self.preprocess_state(obs)
                    self.append_memory((state, a, reward, next_state, done))
                    state = next_state
                    loss = self.train(done)
                    episode_loss.append(loss.to(cpu).detach().numpy())
                    episode_reward += reward

                    #                     self.env.render()

                    if episode > start_train_episode and (step + 1) % update_step == 0:
                        self.target_network_update()

                    if done:

                        episode_loss = np.array(episode_loss).mean()

                        losses.append(episode_loss)
                        rewards.append(episode_reward)

                        if (episode + 1) % show_episode == 0:
                            losses = np.array(losses).mean()
                            rewards = np.array(rewards).mean()
                            print(
                                'Episode : {:4d} // Step : {:5d} // Loss: {:3f} // Reward : {:3f} // Epsilon : {:3f}'.format(
                                    episode + 1, step, losses, rewards, self.epsilon))
                            losses = []
                            rewards = []

                        if episode > start_train_episode and (episode + 1) % save_episode == 0:
                            torch.save(self.agent.state_dict(), save_path)


if __name__ == '__main__':
    ddqn = DDQN()
    ddqn.run()












