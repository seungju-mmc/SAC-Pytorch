import torch
import torch.nn as nn


def find_activation(string):
    string = string.lower()


    if string == 'relu':
        activation = torch.nn.ReLU()
    elif string =='leaky_relu':
        activation = torch.nn.LeakyReLU()
    elif string == 'sigmoid':
        activation=torch.nn.Sigmoid()
    elif string == 'tanh':
        activation = torch.nn.Tanh()
    else:
        activation = torch.nn.Linear()

    return activation


class View(nn.Module):
    def __init__(self):
        super(View, self).__init__()

    def forward(self,x):
        return torch.flatten(x, start_dim=1)

class Nomramlization(nn.Module):
    def __init__(self):
        super(Nomramlization,self).__init__()

    def forward(self,x):
        x = x.float()
        return x/255.



class DQN_Agent(nn.Module):

    def __init__(self, parms):
        super(DQN_Agent, self).__init__()
        # x_e = (x_i + 2 * padding - filter_size)/strides +1
        if len(parms['state_size']) >= 3:
            self.mode = 'Image'
        else:
            self.mode = 'Vector'

        self.parms = parms

        activation = find_activation(parms['activation'])

        if self.mode =='Image':
            model = nn.Sequential()
            init_size = parms['state_size'][0]
            if parms['normalization'] =='True':
                model.add_module('normal',Nomramlization())
            for i in range(parms['num_of_layers']):
                model.add_module("conv_"+str(i+1), torch.nn.Conv2d(init_size, parms['filter_size'],
                                                                   parms['kernel_size'], padding=parms['padding']))
                init_size = parms['filter_size']
                model.add_module("maxpool_"+str(i+1), torch.nn.MaxPool2d(2))
                model.add_module("relu_"+str(i+1), activation)

            model.add_module('reshape', View())
            rand_example = torch.rand((1, parms['state_size'][0], parms['state_size'][1], parms['state_size'][2]))
            output_shape = model.forward(rand_example).shape
            model.add_module('fc1', torch.nn.Linear(output_shape[-1], parms['fully_connected_size']))
            model.add_module('relu', activation)
            model.add_module('Q', torch.nn.Linear(parms['fully_connected_size'],parms['action_size']))
            self.model = model


        elif self.mode =='Vector':
            model = nn.Sequential()
            init_size = parms['state_size'][0] * parms['state_size'][1]
            for i in range(parms['num_of_layers']):
                model.add_module("fc_"+str(i+1), torch.nn.Linear(init_size, parms['filter_size']))
                init_size = parms['filter_size']
                model.add_module("relu_"+str(i+1), activation)
            model.add_module('Q',torch.nn.Linear(parms['filter_size'],parms['action_size']))
            self.model = model

        self.device = torch.device(parms['device'])
        self.model.to(self.device)


    def forward(self, state):
        if ~torch.is_tensor(state):
            state = torch.tensor(state).to(self.device).float()
        shape = [-1]
        if self.mode == 'Vector':
            shape = [-1, self.parms['state_size'][0]*self.parms['state_size'][1]]
        elif self.mode == 'Image':
            for i in self.parms['state_size']:
                shape.append(i)

        state = state.view(shape)

        x = self.model(state)
        return x

    def loss(self, states, targets, actions):
        values = self.forward(states)
        values = torch.stack([values[action[0], action[1]] for action in actions])
        targets = torch.stack(targets)

        loss = torch.mean((values-targets.detach()).pow(2))

        return loss

class Agent:
    def __init__(self, agent_parser):
        if agent_parser['algorithm'] == 'DQN':
            self.agent = DQN_Agent(agent_parser)
        else:
            self.agent = None

    def load_agent(self):
        return self.agent
