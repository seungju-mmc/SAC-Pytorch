from utils import OFF_Policy

if __name__ =='__main__':

    algorithm = OFF_Policy('01_DQN_config.json')
    algorithm.run()



