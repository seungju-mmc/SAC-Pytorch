import json



class Json_Config_Parser:

    def __init__(self, file_name):

        with open(file_name) as json_file:
            self.json_data = json.load(json_file)

    def load_parser(self):
        return self.json_data

    def load_agent_parser(self):
        return self.json_data.get('agent')

    def load_optimizer_parser(self):
        return self.json_data.get('optimizer')



